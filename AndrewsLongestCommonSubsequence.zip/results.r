library(ggplot2)

#length 15
a<-c(0,0,0,0,0,2,1,1,2,4,2,4,4,3,3)
a1<-c(0.03,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
b<-c(0,0,0,0,0,2,1,1,2,4,2,4,4,3,3)
b1<-c(0.05,0,0,0,0,0,0,0.03,0.14,0.78,2.46,10.32,35.61,127.16,576.61)

#length 20
a2<-c(31,63,93,132,165,186,224,251,280,313,347,384,411,448,475,511,550,585,611,636)
a21<-c(0.01,0.10,0.18,0.33,0.49,0.84,1.19,1.63,1.48,1.97,2.27,2.68,3.18,4.61,4.65,5.14,5.64,6.78,7.39,8.40)


theoryB<-c(1:15)
theoryO<-c(100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000)

comp<-rbind(a,a1,b,b1,theoryB)
rownames(comp)<-c("DP","DPT","BF","BFT","Length")
colnames(comp)<-c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
comp.d<-as.data.frame(t(comp))
# str(comp.d)
# comp.d$DP

ggplot()+geom_line(data=comp.d,aes(x= DPT,y= DP),color="blue1")+geom_point(data=comp.d,aes(x= DPT,y= DP),color="blue")+geom_line(data=comp.d,aes(x= BFT,y= BF),color="green1")+geom_point(data=comp.d,aes(x= BFT,y= BF),color="green")+xlab("Time (sec)")+ylab("LCS Length")+ggtitle("Actual DP vs BF")

ggplot(comp.d,aes(x=DPT,y=DP))+geom_line(data=comp.d,aes(x=DPT,y=DP),color="blue")+geom_point(data=comp.d,aes(x=DPT,y=DP),color="blue1")+xlab("Time (sec)")+ylab("LCS Length")+ggtitle("Actual DP")

ggplot(comp.d,aes(x=BF,y=BFT))+geom_line(data=comp.d,aes(x=BFT,y=BF),color="green1")+geom_point(data=comp.d,aes(x=BFT,y=BF),color="green")+xlab("Time (sec)")+ylab("LCS Length")+ggtitle("Actual BF")

run<-rbind(a2,a21,theoryO)
rownames(run)<-c("DPE","DPET","Length")
colnames(run)<-c("100","200","300","400","500","600","700","800","900","1000","1100","1200","1300","1400","1500","1600","1700","1800","1900","2000")
run.d<-as.data.frame(t(run))
#str(run.d)
ggplot(run.d,aes(x=DPE,y=DPET))+geom_line(data=run.d,aes(x=DPET,y=DPE),color="plum")+geom_point(data=run.d,aes(x=DPET,y=DPE),color="purple")+xlab("Time (sec)")+ylab("LCS Length")+ggtitle("Actual DP Extended")


ggplot()+geom_line(data=comp.d,aes(x= DPT,y= Length),color="blue1")+geom_point(data=comp.d,aes(x= DPT,y= Length),color="blue")+geom_line(data=comp.d,aes(x= BFT,y= Length),color="green1")+geom_point(data=comp.d,aes(x= BFT,y= Length),color="green")+xlab("Time (sec)")+ylab("String Length")+ggtitle("Actual DP vs BF")

ggplot(comp.d,aes(x=DPT,y=Length))+geom_line(data=comp.d,aes(x=DPT,y=Length),color="blue")+geom_point(data=comp.d,aes(x=DPT,y=Length),color="blue1")+xlab("Time (sec)")+ylab("String Length")+ggtitle("Actual DP")

ggplot(comp.d,aes(x=BFT,y=Length))+geom_line(data=comp.d,aes(x=BFT,y=Length),color="green1")+geom_point(data=comp.d,aes(x=BFT,y=Length),color="green")+xlab("Time (sec)")+ylab("String Length")+ggtitle("Actual BF")

ggplot(run.d,aes(x=DPE,y=Length))+geom_line(data=run.d,aes(x=DPET,y=Length),color="plum")+geom_point(data=run.d,aes(x=DPET,y=Length),color="purple")+xlab("Time (sec)")+ylab("String Length")+ggtitle("Actual DP Extended")

#holds theoretical value of BF
theoryBF<-vector()
#DP
theoryDPV<-vector()
#DPE
theoryDP<-vector()
#used to hold values of c for each run 
#15 runs
theoryBF1<-vector()
theoryDPV1<-vector()
#20 runs
theoryDP1<-vector()
for(i in theoryB)
{
  theoryBF[i]<-(2^i)
  theoryDPV[i]<-(i*i)
}
for(j in theoryO)
{
  theoryDP[j/100]<-(j*j)
}
# theoryBF
# theoryDPV
# theoryDP

#caculate the c values
for(l in 1:15)
{
  theoryBF1[l]<-b1[l]/theoryBF[l]
  theoryDPV1[l]<-a1[l]/theoryDPV[l]
}
for(k in 1:20)
{
  theoryDP1[k]<-a21[k]/theoryDP[k]
}
#get max c value for each method
cBF<-max(theoryBF1)
cDPV<-max(theoryDPV1)
cDP<-max(theoryDP1)

#get theory values multiplied by the max c value
for(l in 1:15)
{
  theoryBF[l]<-theoryBF[l]*cBF
  theoryDPV[l]<-theoryDPV[l]*cDPV
}
for(k in 1:20)
{
  theoryDP[k]<-theoryDP[k]*cDP
}
theoryBF
theoryDPV
theoryDP

# 0.03 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00 0.00
# 0.05   0.00   0.00   0.00   0.00   0.00   0.00   0.03   0.14   0.78   2.46  10.32  35.61 127.16 576.61
# 0.01 0.10 0.18 0.33 0.49 0.84 1.19 1.63 1.48 1.97 2.27 2.68 3.18 4.61 4.65 5.14 5.64 6.78 7.39 8.40

theory<-rbind(theoryDPV,theoryBF,theoryB)
#DP thoery, BF theory, length of strings
rownames(theory)<-c("DPTR","BFTR","Length")
colnames(theory)<-c("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15")
theory.d<-as.data.frame(t(theory))
# str(comp.d)
# comp.d$DP
ggplot()+geom_line(data=theory.d,aes(x=DPTR,y=Length),color="cyan")+geom_point(data=theory.d,aes(x= DPTR,y=Length),color="cyan1")+geom_line(data=theory.d,aes(x=BFTR,y=Length),color="darkgoldenrod")+geom_point(data=theory.d,aes(x= BFTR,y=Length),color="darkgoldenrod1")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory DP vs BF")

ggplot(theory.d,aes(x=DPTR,y=Length))+geom_line(data=theory.d,aes(x=DPTR,y=Length),color="cyan")+geom_point(data=theory.d,aes(x=DPTR,y=Length),color="cyan1")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory DP")

ggplot(comp.d,aes(x=BFTR,y=Length))+geom_line(data=theory.d,aes(x=BFTR,y=Length),color="darkgoldenrod")+geom_point(data=theory.d,aes(x=BFTR,y=Length),color="darkgoldenrod1")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory BF")


#DPE theory, length of strings
extend<-rbind(theoryDP,theoryO)
rownames(extend)<-c("DPRT","Length")
colnames(extend)<-c("100","200","300","400","500","600","700","800","900","1000","1100","1200","1300","1400","1500","1600","1700","1800","1900","2000")
extend.d<-as.data.frame(t(extend))

ggplot(extend.d,aes(x=DPRT,y=Length))+geom_line(data=extend.d,aes(x=DPRT,y=Length),color="coral")+geom_point(data=extend.d,aes(x=DPRT,y=Length),color="coral1")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory DP Extended")

ggplot()+geom_line(data=extend.d,aes(x=DPRT,y=Length),color="coral")+geom_point(data=extend.d,aes(x=DPRT,y=Length),color="coral1")+geom_line(data=run.d,aes(x=DPET,y=Length),color="plum")+geom_point(data=run.d,aes(x=DPET,y=Length),color="purple")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory DP vs Actual DP Extended")

ggplot()+geom_line(data=theory.d,aes(x=DPTR,y=Length),color="cyan")+geom_point(data=theory.d,aes(x=DPTR,y=Length),color="cyan1")+geom_line(data=comp.d,aes(x=DPT,y=Length),color="blue")+geom_point(data=comp.d,aes(x=DPT,y=Length),color="blue1")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory DP vs Actual DP")

ggplot()+geom_line(data=theory.d,aes(x=BFTR,y=Length),color="darkgoldenrod")+geom_point(data=theory.d,aes(x=BFTR,y=Length),color="darkgoldenrod1")+geom_line(data=comp.d,aes(x=BFT,y=Length),color="green1")+geom_point(data=comp.d,aes(x=BFT,y=Length),color="green")+xlab("Run Time")+ylab("String Length")+ggtitle("Theory BF vs Actual BF")